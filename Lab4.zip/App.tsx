import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

import Bai1_2 from './src/app/Bai1_2';
import Bai3 from './src/app/Bai3';

const Stack = createNativeStackNavigator();


const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName='Bài 1 2'>
        <Stack.Screen name="Bài 1 2" component={Bai1_2} />
        <Stack.Screen name="Bài 3" component={Bai3} />
      </Stack.Navigator>
    </NavigationContainer>
  )
}

export default App

const styles = StyleSheet.create({})